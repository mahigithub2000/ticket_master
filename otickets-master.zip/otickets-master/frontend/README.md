# OTickets - Ticket Support System [Frontend]

Please check the main readme file for more information about this project from <a href="https://github.com/omaghd/otickets/README.md">here</a>.