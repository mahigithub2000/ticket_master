<template>
  <div class="h-5 w-60 animate-pulse rounded bg-gray-200"></div>
</template>
