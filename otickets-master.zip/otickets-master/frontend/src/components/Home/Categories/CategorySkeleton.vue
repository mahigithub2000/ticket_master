<template>
  <div class="flex w-96 max-w-full animate-pulse flex-col rounded-lg border bg-white">
    <div class="flex-1 p-6 text-center">
      <div>
        <div class="h-7 w-full rounded bg-gray-200"></div>
      </div>
    </div>
  </div>
</template>
