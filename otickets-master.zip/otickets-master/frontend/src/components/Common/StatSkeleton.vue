<template>
  <div class="animate-pulse overflow-hidden rounded-lg border bg-white px-4 py-5 shadow sm:p-6">
    <div class="h-5 w-24 max-w-full rounded bg-gray-200"></div>
    <div class="mt-2 h-8 w-8 max-w-full rounded bg-gray-200"></div>
  </div>
</template>
