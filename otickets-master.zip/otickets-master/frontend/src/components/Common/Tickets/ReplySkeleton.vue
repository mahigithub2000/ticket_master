<template>
  <div class="animate-pulse divide-y rounded-lg border shadow">
    <div class="p-3">
      <div class="flex gap-1">
        <div class="h-14 w-14 rounded-full bg-gray-200"></div>

        <div>
          <div class="h-4 w-64 max-w-full rounded bg-gray-200"></div>
          <div class="mt-2 h-3 w-52 max-w-full rounded bg-gray-200"></div>
        </div>
      </div>

      <div class="mt-1 h-32 w-full rounded bg-gray-200"></div>
    </div>
  </div>
</template>
