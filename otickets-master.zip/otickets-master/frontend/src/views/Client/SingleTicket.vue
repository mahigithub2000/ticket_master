<script setup lang="ts">
import SingleTicket from '@/components/Common/Tickets/SingleTicket.vue'
</script>

<template>
  <SingleTicket custom-class="py-6 px-4 sm:p-6 lg:pb-8" />
</template>
