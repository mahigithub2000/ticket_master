type DepartmentsFilters = {
  page?: number | null
  trash?: boolean | null
  query?: string | null
  paginate?: boolean | null
}

export default DepartmentsFilters
