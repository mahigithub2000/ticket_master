type Newsletter = {
  id: number
  email: string
  ip_address: string
  user_agent: string
  created_at: string
}

export default Newsletter
