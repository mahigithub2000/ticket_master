type FaqsFilters = {
  page?: number | null
  trash?: boolean | null
  query?: string | null
  category?: number | null
  dates?: string[] | null
}

export default FaqsFilters
