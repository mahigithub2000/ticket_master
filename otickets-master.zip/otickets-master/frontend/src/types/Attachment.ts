type Attachment = {
  id: number
  filename: string
  path: string
  created_at: string
}

export default Attachment
