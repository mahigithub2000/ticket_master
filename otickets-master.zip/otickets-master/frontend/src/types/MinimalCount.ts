type MinimalCount = {
  name: string
  count: number
}

export default MinimalCount
