type Page = {
  name: string
  to: string
  params?: { slug: string }
}

export default Page
