type Department = {
  id: number
  name: string
  agents_count: number
  categories_count: number
  created_at: string
}

export default Department
