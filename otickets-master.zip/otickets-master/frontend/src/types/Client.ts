type Client = {
  id: number
  name: string
  email: string
  phone: string
  picture: string
  created_at: string
  tickets_count: number
}

export default Client
