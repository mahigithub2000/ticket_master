type CategoriesFilters = {
  page?: number | null
  trash?: boolean | null
  query?: string | null
  department?: string | null
  paginate?: boolean | null
}

export default CategoriesFilters
