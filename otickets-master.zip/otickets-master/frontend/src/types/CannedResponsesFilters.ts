type CannedResponsesFilters = {
  page?: number | null
  trash?: boolean | null
  paginate?: boolean | null
  query?: string | null
  agent?: number | null
  category?: number | null
}

export default CannedResponsesFilters
