type Option = {
  name: string
  value: string
}

export default Option
