type NewReply = {
  action: string
  ticket_id: number
  content: string
  attachments: File[]
}

export default NewReply
