type NewslettersFilters = {
  page?: number | null
  query?: string | null
}

export default NewslettersFilters
