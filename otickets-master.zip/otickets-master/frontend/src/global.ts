export const appTitle = 'OTickets'
export const apiURL = import.meta.env.VITE_API_URL
